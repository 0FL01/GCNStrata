#!/usr/bin/env python3
"""CPU-only deterministic QSTRAN01 graph transition fixtures. No GPU/timing."""
import argparse, hashlib, json, pathlib, struct
from analyze_qsa_dump import order_key, analyze_row

GUARD = 0x13579bdf
SCORE_CAP = 65537  # full 262144-cell capacity incl zero-weight spare
OUT_CAP = 2080   # deliberately includes per-row unused suffix

def oracle(nkv, bits):
    width = min(nkv, 2051)
    ids = []
    for b in sorted(range(len(bits)), key=lambda b: (-order_key(bits[b]), b)):
        w = min(4, nkv - 4*b)
        ids.extend(range(4*b, 4*b + min(w, width-len(ids))))
        if len(ids) == width: break
    return sorted(ids)

def scores(active, pattern, salt):
    if pattern == 0:  # large ties and exact bitwise exceptional cases
        pool = [0, 0x80000000, 0x3f800000, 0x3f800000, 0x7fc00001,
                0xffc00007, 0x7f800000, 0xff800000, 0xbf800000, 0x00000001]
        return [pool[(b*7+salt)%len(pool)] for b in range(active)]
    if pattern == 1: return [0x7fc00001 if b%2 else 0xffc00007 for b in range(active)]
    if pattern == 2: return [0x80000000 if (b+salt)%2 else 0 for b in range(active)]
    # Pseudorandom integer float bits; no host float conversions/rounding.
    x = 0x9e3779b9 ^ salt; out=[]
    for _ in range(active):
        x ^= (x << 13) & 0xffffffff; x ^= x >> 17; x ^= (x << 5) & 0xffffffff
        x &= 0xffffffff; out.append(x)
    return out

def cases(nq):
    def same(n): return [n]*nq
    out=[]
    # Same graph moves up and down BOTH dispatch thresholds repeatedly.
    values=[1, 2048, 2051, 24575, 24576, 24577, 65536,
            135164,135165,135166,135167,135168,135169,135170,135171,
            262144,135167,24576,17,24577,135168,65539,24573]
    for i,n in enumerate(values): out.append((f'uniform_{i:02d}_{n}',same(n),i%4))
    if nq>1:
        # Normal monotonic batches straddle each boundary.
        out += [('straddle_low',[24576-nq//2+i for i in range(nq)],0),
                ('straddle_middle',[135168-nq//2+i for i in range(nq)],3)]
        # Last-row-only reg33 guard would overflow on the earlier long row.
        a=same(65539); a[0]=135168
        out.append(('earlier_long_last_middle',a,3))
        a=same(65539); a[-2]=262144
        out.append(('penultimate_long_last_middle',a,0))
        a=same(24576); a[0]=262144
        out.append(('earlier_long_last_reference',a,0))
        # End on a small row to verify shrinking and stale-output handling.
        out += [('shrink_mixed',[([1,17,2048,2051,24575,24576])[i%6] for i in range(nq)],2)]
    return out

def generate(outdir,nq):
    cs=cases(nq); path=outdir/f'reg33-transition-t{nq}.bin'; manifest=[]
    with path.open('wb') as f:
        f.write(struct.pack('<8s8I',b'QSTRAN01',1,0x01020304,nq,SCORE_CAP,OUT_CAP,4,len(cs),16))
        for ci,(name,nkvs,pattern) in enumerate(cs):
            expected_route='unchanged_fallback' if nq>8 else ('reference' if nkvs[-1]<=24576 else ('middle33' if max(n//4+1 for n in nkvs)<=33792 else 'wide66'))
            bname=name.encode(); f.write(struct.pack('<I',len(bname))); f.write(bname)
            steps=[]; rows=[]
            for row,nkv in enumerate(nkvs):
                step=(nkv-1,nkv,nkv//4,min(nkv,2051)); steps.extend(step)
                bits=scores(nkv//4+1,pattern,ci*17+row)
                ids=oracle(nkv,bits)
                # Independent weighted radix reconstruction from the vetted parser.
                analyze_row({'step':step,'bits':bits,'ids':ids})
                rows.append((bits,ids))
            f.write(struct.pack('<'+'i'*len(steps),*steps))
            for bits,ids in rows:
                f.write(struct.pack('<2I',len(bits),len(ids)))
                f.write(struct.pack('<'+'I'*len(bits),*bits))
                f.write(struct.pack('<'+'i'*len(ids),*ids))
            manifest.append(dict(name=name,nkv=nkvs,pattern=pattern,expected_route=expected_route,
                                 max_active_blocks=max(n//4+1 for n in nkvs),tails=[n%4 for n in nkvs]))
    return dict(file=path.name,sha256=hashlib.sha256(path.read_bytes()).hexdigest(),nq=nq,cases=manifest)

def main():
    p=argparse.ArgumentParser();p.add_argument('outdir',type=pathlib.Path);a=p.parse_args();a.outdir.mkdir(parents=True,exist_ok=True)
    result=dict(format='QSTRAN01',gpu_executed=False,timing_claim=False,
                oracle='integer IEEE keys + ascending tie IDs; checked against weighted radix parser',
                fixtures=[generate(a.outdir,t) for t in (1,4,6,8,9)])
    (a.outdir/'reg33-transition-manifest.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({x['file']:x['sha256'] for x in result['fixtures']},indent=2))
if __name__=='__main__': main()
