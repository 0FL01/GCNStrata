# Correctness-only reg33 graph transition harness

Prepared independently of the patch. No build or GPU execution was performed. No timing claims. The existing `qsa_topk_fixture_replay.cpp` is unchanged.

## Files

- `qsa_reg33_transition.cpp`: standalone HIP driver calling the unchanged production API (no count pointer).
- `generate_reg33_transitions.py`: deterministic CPU fixture generator; imports the adjacent vetted `analyze_qsa_dump.py` for integer IEEE order keys and independent weighted-radix verification of every generated row.
- `reg33-transition-fixtures/reg33-transition-t{1,4,6,8,9}.bin`: generated packed fixtures.
- `reg33-transition-fixtures/reg33-transition-manifest.json`: case names, all row lengths, expected candidate routes, tail counts, and fixture hashes.
- `reg33-transition-SHA256SUMS`: complete deliverable hashes.

Each T gets exactly one graph instantiation with one production selector invocation. No graph updates, allocation, host copies, or reference invocation are captured. Scores and device steps are updated outside the graph before each replay. All device addresses, T, and capacities remain constant. Output is reset to -1 before every replay, with end canaries; comparison includes the entire allocation, including each row's padding. Input score and step bytes, including guards, are verified immediately after the graph and again after the standalone reference.

The score stride is 65537 blocks (262144-cell capacity including a zero-weight spare). Output stride is 2080 IDs, including intentional unused suffix beyond max width 2051. Inactive scores are poisoned with +Inf. Zero-weight tail/spare score is supplied normally and must not contribute cells. End score and step guards also detect writes. This does not detect benign out-of-bounds reads; sanitizer coverage remains separate.

## Coverage and CPU checks

CPU generation succeeded for 23 T1 cases and 29 cases each for T4, T6, T8, and T9 (806 total rows). Every row's sorted oracle was independently reconstructed by the existing weighted-radix parser.

The sequence repeatedly crosses reference/long (last-row nkv 24576/24577) and reg33/wide (maximum active blocks 33792/33793, normal nkv 135167/135168), reaches nkv 262144, and shrinks to small contexts. It covers tails 0/1/2/3 on both sides of the middle threshold, monotonic batches straddling thresholds, earlier-long/last-middle and penultimate-long/last-middle batches, earlier-long/last-reference batches, and mixed shrinking batches.

T8 exercises the new host guard upper bound; T9 exercises the unchanged fallback and makes no reg33 routing claim.

Patterns include large ties, all NaNs, both NaN signs, all signed zeros, infinities, subnormals, and deterministic arbitrary IEEE bit patterns. Expected route labels printed by the driver are a specification prediction, NOT proof of device branch execution. Actual kernel/ISA and patch trace evidence remain separate gates.

## Deterministic regeneration

The script-only bundle excludes large fixture binaries. On the destination run:

    python3 generate_reg33_transitions.py reg33-transition-fixtures
    sha256sum -c reg33-transition-SHA256SUMS

All packed fields use explicit little-endian formats and score generation uses integer-only arithmetic with fixed seeds. Expected fixture hashes are supplied in the bundle and must match before GPU use.

## Future authorized build/run recipe (not executed)

Build the patched selector archive separately with `STRATA_GFX906_TOPK_MID_PROBE=1`. Do not use a stale unpatched archive. Record the source/archive/driver hashes and compiler commands. Link this driver to that exact archive. The known qualified compiler pattern is:

    /opt/rocm/lib/llvm/bin/clang++ -x hip -O3 -DNDEBUG -std=c++20 \
      --offload-arch=gfx906 -Wall -Wextra \
      -DSTRATA_HIP_GFX906=1 -DUSE_PROF_API=1 \
      -D__HIP_PLATFORM_AMD__=1 -D__HIP_ROCclr__=1 \
      -I"$QUAL/include/strata/platform/hip_compat" -I"$QUAL/include" \
      "$WORK/qsa_reg33_transition.cpp" -x none "$PATCHED_ARCHIVE" \
      -L/opt/rocm/lib -Wl,-rpath,/opt/rocm/lib -lamdhip64 \
      -o "$WORK/qsa_reg33_transition"

The qualified HIP shim MUST precede the main include root. Driver compile and runtime guards require gfx906 and wave64. Run every fixture in fresh processes for baseline and candidate because route environment configuration may be cached:

    unset STRATA_TOPK_OLD
    export STRATA_GFX906_TOPK_REG=2 STRATA_TOPK_TRACE=1
    for mid in 0 1; do
      for t in 1 4 6 8 9; do
        STRATA_GFX906_TOPK_MID=$mid "$WORK/qsa_reg33_transition" \
          "$WORK/reg33-transition-fixtures/reg33-transition-t$t.bin" 0 \
          > "$WORK/transition-mid$mid-t$t.log" 2>&1
      done
    done

Use a fail-fast shell (`set -eu`) and preserve every log. Require all ten process exit statuses zero, each expected CASE_PASS count, and one TRANSITION_PASS per process. For candidate logs require the patch trace `candidate=1 middle_blocks=33792 device_max_guard=1`; baseline logs should show `candidate=0`. The driver can validate output parity on an unpatched archive, so the candidate trace plus separately verified archive provenance is essential. Running a baseline must NOT be mislabeled as testing the reg33 branch.

No fixture replay timing is collected. This correctness suite does not replace register/spill/LDS/ISA checks, real captured-score timing, or whole-model qualification.
