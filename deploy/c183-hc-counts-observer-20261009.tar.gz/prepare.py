#!/usr/bin/env python3
"""Generate reviewable host-only source patch from exact pinned inputs; no build/run."""
import hashlib,json,difflib,re
from pathlib import Path
HERE=Path(__file__).resolve().parent
PINS={'gemm.cu':'6f73546e4b654a9cc81f4b333a09530c7425e13f6ce33ac16ecb88a05b07fabd','prefill.cpp':'1a8855dd4e1d6116f10060f2be2110014ecc2afb9e80c9164fc0689c8f175b42','generate.cpp':'2a1b3192b70fd56780fb6732c392abf54ff4f017279a6c3a463e0dac5b22d24e','gemm.hpp':'a46c76cad934f4c4114a0f984aee2a7145c8549fc7b1efee16b09d62aab2cfaf'}
def sha(data):return hashlib.sha256(data).hexdigest()
def replace(s,old,new,count=1):
 if s.count(old)!=count:raise ValueError('anchor occurrence mismatch: '+old[:70])
 return s.replace(old,new)
def device_functions(s):
 result=[]
 for m in re.finditer(r'__global__\s+void\s+\w+',s):
  start=m.start();at=s.index('{',m.end());depth=1;end=at+1
  while depth:
   depth+=(s[end]=='{')-(s[end]=='}');end+=1
  result.append(s[start:end])
 return result
def generate():
 src={name:(HERE/'original'/name).read_text() for name in PINS}
 for name,digest in PINS.items():
  if sha(src[name].encode())!=digest:raise ValueError('original source changed: '+name)
 g=src['gemm.cu'];g=replace(g,'#include "strata/prefill/gemm.hpp"','#include "strata/prefill/gemm.hpp"\n#include "strata/prefill/hc_counts_observer.hpp"')
 g=replace(g,'Gemm::~Gemm() {','Gemm::~Gemm() {\n    hc_observer::flush(this, hc_f16_attempts_, hc_f16_taken_);')
 g=replace(g,'    stream_ = stream;','    stream_ = stream;\n    hc_observer::start(this);',2)
 g=replace(g,'void Gemm::rebind(uint16_t* scratch, int64_t scratch_elems, void* workspace, size_t ws_bytes) {','void Gemm::rebind(uint16_t* scratch, int64_t scratch_elems, void* workspace, size_t ws_bytes) {\n    hc_observer::rebind(this);')
 g=replace(g,'    ++hc_f16_attempts_;','    ++hc_f16_attempts_;\n    const auto hc_observation = hc_observer::attempt(this, W, (unsigned)N, (unsigned)K, (unsigned)T);')
 old='''    if (!hc_scratch_ || hc_scratch_bytes_ < need || ldy < N || ldy > std::numeric_limits<int>::max() ||
        (uint64_t)ldy > std::numeric_limits<size_t>::max() / (4 * (uint64_t)T)) return false;'''
 new='''    if (!hc_scratch_ || hc_scratch_bytes_ < need || ldy < N || ldy > std::numeric_limits<int>::max() ||
        (uint64_t)ldy > std::numeric_limits<size_t>::max() / (4 * (uint64_t)T)) {
        hc_observer::finish(hc_observation, !hc_scratch_ ? hc_observer::NoScratch : hc_scratch_bytes_ < need ? hc_observer::SmallScratch : ldy < N ? hc_observer::LdySmall : ldy > std::numeric_limits<int>::max() ? hc_observer::LdyLarge : hc_observer::YSizeOverflow);
        return false;
    }''';g=replace(g,old,new)
 g=replace(g,'    if (hc_scratch_bytes_ > std::numeric_limits<uintptr_t>::max() - sb) return false;','    if (hc_scratch_bytes_ > std::numeric_limits<uintptr_t>::max() - sb) { hc_observer::finish(hc_observation, hc_observer::ScratchOverflow); return false; }')
 g=replace(g,'    if (overlaps(X, xe * 2) || overlaps(W, we * 2) || overlaps(Y, (uint64_t)T * ldy * 4)) return false;','    if (overlaps(X, xe * 2) || overlaps(W, we * 2) || overlaps(Y, (uint64_t)T * ldy * 4)) {\n        hc_observer::finish(hc_observation, overlaps(X, xe * 2) ? hc_observer::XOverlap : overlaps(W, we * 2) ? hc_observer::WOverlap : hc_observer::YOverlap); return false;\n    }\n    hc_observer::eligible(hc_observation);')
 g=replace(g,'        check(cudaStreamSynchronize(st), "scaled guard sync");','        check(cudaStreamSynchronize(st), "scaled guard sync");\n        hc_observer::observe(hc_observation, guard);')
 g=replace(g,'        if (guard[1] || guard[6] || guard[2] || guard[7]) {','        if (guard[1] || guard[6] || guard[2] || guard[7]) {\n            hc_observer::finish(hc_observation, hc_observer::RangeReject);')
 g=replace(g,'        if (exact_input && (guard[3] || guard[8])) {','        if (exact_input && (guard[3] || guard[8])) {\n            hc_observer::finish(hc_observation, hc_observer::ExactReject);')
 g=replace(g,'    if (arena_only) {','    if (arena_only) {\n        hc_observer::finish(hc_observation, hc_observer::ArenaOnly);')
 g=replace(g,'    ++hc_f16_taken_;','    ++hc_f16_taken_;\n    hc_observer::finish(hc_observation, hc_observer::Taken);')
 p=src['prefill.cpp'];p=replace(p,'#include "strata/prefill/gemm.hpp"','#include "strata/prefill/gemm.hpp"\n#include "strata/prefill/hc_counts_observer.hpp"')
 p=replace(p,'        const int64_t T = std::min(m.T, n - c0), p0 = pos0 + c0;','        const int64_t T = std::min(m.T, n - c0), p0 = pos0 + c0;\n        hc_observer::chunk(&m.gemm, (unsigned)T, (uint64_t)p0, (int)LB, (int)LE, m.device, m.wt, m.ss, m.cs);')
 p=replace(p,'                    void clear() { gemm.set_hc_scratch(nullptr, 0); }','                    void clear() { gemm.set_hc_scratch(nullptr, 0); hc_observer::clear_bindings(&gemm); }')
 p=replace(p,'                if (!wn || !wd || !wu || !wi) return false;','''                if (!wn || !wd || !wu || !wi) return false;
#if defined(STRATA_HIP_GFX906)
                hc_observer::declare_weight(&m.gemm, wd->data, (unsigned)(1 + 4*l + 2*half), (unsigned)wd->ne1, (unsigned)wd->ne0);
                hc_observer::declare_weight(&m.gemm, wu->data, (unsigned)(2 + 4*l + 2*half), (unsigned)wu->ne1, (unsigned)wu->ne0);
#endif''')
 if device_functions(g)!=device_functions(src['gemm.cu']):raise ValueError('device function source changed')
 api=r'(?:cuda|hip)(?:MemcpyAsync|StreamSynchronize|DeviceSynchronize|MemsetAsync|Event\w+)\s*\([^;]+;'
 if re.findall(api,g)!=re.findall(api,src['gemm.cu']):raise ValueError('device copy/sync/event API source changed')
 launch=lambda s:re.findall(r'[^\n]*<<<[^\n]*',s)
 if launch(g)!=launch(src['gemm.cu']):raise ValueError('kernel launch source changed')
 if re.findall(api,p)!=re.findall(api,src['prefill.cpp']) or launch(p)!=launch(src['prefill.cpp']):raise ValueError('caller GPU operation source changed')
 out=HERE/'patched';(out/'src/prefill').mkdir(parents=True,exist_ok=True);(out/'include/strata/prefill').mkdir(parents=True,exist_ok=True)
 (out/'src/prefill/gemm.cu').write_text(g);(out/'src/prefill/prefill.cpp').write_text(p);(out/'include/strata/prefill/hc_counts_observer.hpp').write_bytes((HERE/'hc_counts_observer.hpp').read_bytes())
 diff=''.join(difflib.unified_diff(src['gemm.cu'].splitlines(True),g.splitlines(True),fromfile='a/src/prefill/gemm.cu',tofile='b/src/prefill/gemm.cu'))+''.join(difflib.unified_diff(src['prefill.cpp'].splitlines(True),p.splitlines(True),fromfile='a/src/prefill/prefill.cpp',tofile='b/src/prefill/prefill.cpp'))+''.join(difflib.unified_diff([], (HERE/'hc_counts_observer.hpp').read_text().splitlines(True),fromfile='/dev/null',tofile='b/include/strata/prefill/hc_counts_observer.hpp'))
 (HERE/'observer.patch').write_text(diff)
 proof=dict(status='HOST_ONLY_SOURCE_PATCH_PREPARED_NOT_BUILT',original_sha256=PINS,patched_gemm_sha256=sha(g.encode()),patched_prefill_sha256=sha(p.encode()),observer_header_sha256=sha((HERE/'hc_counts_observer.hpp').read_bytes()),device_functions_unchanged=len(device_functions(g)),kernel_launch_lines_unchanged=True,device_copy_reset_sync_event_calls_unchanged=True,extra_host_device_queries='None: caller supplies m.device under its existing OnDevice scope; no new GPU API',source_provenance_limit='gemm.cu pinned to c183 device evidence; exported caller/header/program are current-worktree source, not proof each was compiled into c183',required_next_gate='Independent source review, root host/device build, unchanged device ELF proof, then separately authorized counts-only model probe')
 (HERE/'source-proof.json').write_text(json.dumps(proof,indent=2)+'\n');return proof
if __name__=='__main__':print(json.dumps(generate(),indent=2))
