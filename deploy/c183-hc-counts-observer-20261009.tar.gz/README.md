# Counts-only static-W-bad falsifier

Prepared host-only observer, not a shortcut. No timing events, kernel changes, extra GPU query, copy, reset, synchronization or model run. It preserves the current SCALED+EXACT/AUDIT0 route and every original return decision. The original c183 binary and source stay untouched. Root owns a separately admitted diagnostic build and any subsequent execution.

## Why counts first

The previous fixed-scale specialization screen is parked: its best optimistic scenario was2.565661ms against1003.739604ms. Reusing absolute baseline converter timings gives680.966–683.160ms for deleting all primary converter calls in accepted/sparse synthetic scenarios, including calls that cannot be skipped. Dense synthetic nonfinite/overflow stress is about2022ms and is not established as the model distribution. Reset, D2H and synchronization costs remain unmeasured; no model speed claim follows.

Current captured attempts/taken1728/531 and1344/567 are not numerical rejection counts. Attempts increment before scratch, ldy, size and overlap eligibility. On the actual exact scaled route, the existing10-word host guard after its existing synchronization already gives W mask bits from indices1,2,3 and X mask bits from6,7,8. The observer reads those existing host values only.

## Exact source and prefix

original/gemm.cu is pinned to SHA256 6f73546e4b654a9cc81f4b333a09530c7425e13f6ce33ac16ecb88a05b07fabd and the c183 device-module binding. Current exported prefill.cpp, gemm.hpp and generate.cpp are pinned by source-proof.json, but the export alone does not prove they were compiled unchanged into c183. This provenance limit is an admission blocker until root resolves it.

generate.cpp server read loop ends at n−1 (around8899–8950); read_part passes the selected segment to sp.run (around8794). Its CLI independently defines n_batched=n_prompt−1 (around10133). Prefill::run uses T=min(m.T,n−c0), with c0 advanced by m.T (around1773–1776). The caller loops stage layers LB..LE, two HC halves, then down/up weights (around2099,2161,2206,2235).

The smallest single cold unsplit prefix with TWO full4096 chunks and one4095 tail is12288 input tokens, producing12287 batched positions [4096,4096,4095]. Prefix8192 has only one full chunk and one tail. One request does not repeat its terminal tail; no repeated-tail claim is made.

prompt-12288.ids.json is exactly the first12288 IDs of the frozen65536-token fixture; hashes are in probe-plan.json. The existing baseline args already set --prefill4096, --layer-split27, --prompt-cache0 and --prompt-cache-every0. One fresh process, one GEN request, one generated token and QUIT are planned. No restored conversation, batch peers, cache reuse or segmentation overrides. Actual chunk T and start positions are recorded without GPU work and must equal [4096,4096,4095] and[0,4096,8192]. Any other geometry is a failed admission/coverage check, not permission to rerun automatically.

Existing current control stderr verifies stage0 layers0–26 and stage1 layers27–47. Four logical HC weights per layer (two halves × down/up) give108 declared identities on device0 and84 on device1. Their ordinal is1+4*layer+2*half+projection, where projection0=down and1=up. Expected ordinal sets are1..108 and109..192. Each should be declared three times; maximum attempts are324 and252. Runtime bypasses can reduce attempts or eligible guards, so declared, attempted and guarded coverage are reported separately. An unguarded weight is never classified as W-good.

## Host-only hooks and reconciliation

prepare.py verifies all original source hashes and generates observer.patch plus patched/ copies. It preserves all9 original device function bodies, all kernel-launch source lines, and all copy/reset/sync/event call source in both changed translation units. It adds:

- Gemm init: begin a bounded observation lifetime; no GPU query
- Gemm rebind: increment visible rebind epoch
- Prefill chunk: bind known caller device, model table, session and stream, under the caller's existing OnDevice scope; record chunk geometry and layer bounds
- HC caller: declare down/up tensor ordinals with private pointer/shape bindings before projection dispatch
- HcScratchScope.clear: deactivate those bindings so they cannot leak to unrelated calls
- try_hc_f16: begin an attempt only where the original attempts counter increments; classify the original eligibility failure; record the existing guard; classify the original range/exact/arena/taken terminal decision
- Gemm destruction: emit aggregates after the timed workload, then release observer state

The13 mutually exclusive terminal buckets are no scratch, small scratch, ldy below N, ldy too large, output-size overflow, scratch-address overflow, X overlap, W overlap, Y overlap, range rejection, exact rejection, arena-only and taken. The current diagnostic contract forbids arena-only, so its count must be zero. The first nine plus eligible equal attempts; final four equal eligible; every eligible call must have one guard observation. Taken must match the unchanged original taken counter. Every weight/T row and its mask histogram is independently reconciled against context totals and the exact original decision predicates.

No observer logging occurs in the workload. Mutex-protected bounded host counters can perturb host overhead, so this run supplies counts only. stderr aggregates contain only context/generation/device/tensor ordinals and counts, never addresses, tensor names or contents.

## Lifecycle limits and conservative opportunity

Eight total Gemm observation lifetimes,256 tensor identities per context and eight chunks per context are hard bounds. At most2073 observer JSON rows are permitted; overflow makes the result invalid. Context slots reset when reused, globally unique generations advance, and overflow is reported only at destruction. First runtime use claims the execution thread rather than assuming the initialization thread. Cross-thread execution, changed caller device/model/session/stream binding, stale ticket epochs, in-flight rebinds and unbalanced calls invalidate the result. Tickets capture context, rebind and pointer epochs; inactive or ambiguous bindings invalidate identity coverage.

Private pointer changes advance a visible address epoch. A same-visible-generation W-mask change is reported separately. A reusable-known-W-bad observation requires a previous nonzero identical W mask in that same visible generation; first observations, good→bad changes and cross-generation repeats do not count as reusable known-bad. Repeats may span full→tail chunks; this is repeated W observation, not repeated tail observation.

These checks are not a proof of immutable weight content under in-place mutation. WeightRef identity and a const WeightTable pointer are insufficient to certify allocation/content lifetime. A future negative-metadata shortcut still needs loader/model-owner content-generation and invalidation proof for reload, upload, dequantization, staging reuse, allocator reuse, model/device rebinding and in-place writes. No cache is implemented here. X rejection is never reusable static-W metadata.

## CPU validation

python3 -m unittest -v test_counts.py compiles only test_observer.cpp with ordinary g++, not HIP. It exercises real header counters and output, all early rejection reasons, exact/range decisions, both stage ordinal sets and three chunks, then parses the emitted JSON independently. It tests good→bad transitions, repeated known-bad observations, rebind/pointer epochs, stale tickets, cross-thread use, binding changes, inactive keys, row/lifetime bounds, duplicate/malformed data, mutation rejection with raw-file preservation and prefix minimality. Tests also regenerate the strict source-only patch and verify unchanged device-source/API lists. Actual device-ELF equality is not established by these tests.

parse_counts.py /absolute/private/stderr produces the sanitized reconciled receipt. It requires both stages, exact runtime geometry, declaration sets, bounded rows and terminal records, mask-to-reason consistency and original-counter agreement. Reduced attempt/guard coverage is explicitly reported. It does not infer failure counts from attempts minus taken.

## Root build admission, before any model execution

1. Keep the frozen c183 binary (SHA256 c18316d678a669c309cb95e2f5de9af03fa5573256fd0e093aafc4b41000d049), objects and original tree immutable. Create a separate diagnostic tree/build/output directory.
2. Verify all four source hashes in source-proof.json in that tree. If current-worktree provenance cannot be matched to the frozen build, recover the matching source/object provenance first. Do not silently substitute a nearby checkout.
3. Run git apply --check observer.patch in the separate tree, then apply it. The patch adds include/strata/prefill/hc_counts_observer.hpp and changes only src/prefill/gemm.cu and src/prefill/prefill.cpp. Keep original compile/link flags, compiler/runtime image, feature macros and every unrelated object unchanged. No fast-math or route changes. Record exact commands, compiler versions, source/object hashes and build return codes.
4. Rebuild those translation units and relink a separate observer binary. Extract all device modules from frozen c183 and the observer binary with the established extractor. Require the same module/kernel inventory and exact device-ELF hashes, especially full gemm.gfx906.elf SHA256 5abe1289b549a9fa4ad7da00398fd81179a6d3b414bd2b3c44b749d5e315f377. Compare every kernel's body and resource metadata, not only the HC converter. Any mismatch stops admission; do not relax it without separate independent review. The source-only proof is not a substitute for this binary gate.
5. Independent reviewer checks build provenance and device equality before root authorizes execution. No model run is part of preparation.

## Proposed one-shot probe and stopping rule

probe-plan.json carries the exact current environment/native args and changes only STRATA_HC_COUNTS_ONLY_OBSERVER=1. Preserve SCALED=1, EXACT_INPUT=1, AUDIT=0, and bounds/shadow/arena diagnostics off. Use the existing safety helper/lock and current two-GPU split, high mode190W, cooldown<=55C, critical-minus10C thermal margins, API off and failure cleanup. Root sets an appropriate one-shot model load/prefill watchdog using the established runner; this package has no runnable GPU/model command.

A terminal successful run must have native/cleanup PASS, prompt reuse0,12288 input tokens, one generated token, actual three-chunk geometry, both exact stage ranges, bounded observer rows and all reconciliation checks. Preserve original logs even on parsing failure. Stop after one valid probe or any failure, with no retries to win.

No observed reusable W-bad means park for the observed workload; if guard coverage is incomplete, do not generalize to all tensors. A W-mask change under an unchanged visible generation falsifies the proposed key/lifecycle assumption. Positive repeated W-bad counts permit only a subsequent separately approved cost diagnostic: original reset/W/X/D2H stages and synchronization wait still need measurement. Never count all synchronization wait as removable or add it twice to device work. No shortcut patch, model qualification or speedup claim follows from counts alone.
