import copy,hashlib,json,subprocess,tempfile,unittest
from pathlib import Path
import prepare
import parse_counts as P
HERE=Path(__file__).resolve().parent
class Tests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.tmp=tempfile.TemporaryDirectory();cls.binary=Path(cls.tmp.name)/'observer-test'
  subprocess.run(['g++','-std=c++17','-O2','-Wall','-Wextra','-Werror','-pthread',str(HERE/'test_observer.cpp'),'-o',str(cls.binary)],check=True)
  cls.raw=subprocess.check_output([str(cls.binary),'--fixture'],text=True);cls.rows=[json.loads(x) for x in cls.raw.splitlines()]
 @classmethod
 def tearDownClass(cls):cls.tmp.cleanup()
 def test_compiled_lifecycle_cases(self):
  self.assertIn('PASS',subprocess.check_output([str(self.binary),'--tests'],text=True))
 def test_actual_cpp_to_python_reconciliation(self):
  result=P.parse(self.raw);self.assertTrue(result['passed']);self.assertEqual(sum(c['attempts'] for c in result['contexts']),576);self.assertEqual([c['logical_tensor_rows'] for c in result['contexts']],[108,84]);self.assertTrue(result['full_attempt_coverage']);self.assertEqual([c['chunk_T'] for c in result['contexts']],[[4096,4096,4095]]*2)
 def test_corruption_rejected_and_preserved(self):
  for kind,key in [('hc_observer_summary','attempts'),('hc_observer_weight','mask_hist_4095'),('hc_observer_weight','stages_4096'),('hc_observer_weight','tensor_ordinal'),('hc_observer_summary','chunk_T')]:
   rows=copy.deepcopy(self.rows);r=next(x for x in rows if x['type']==kind)
   if isinstance(r[key],list):r[key][0]+=1
   else:r[key]+=1
   raw='\n'.join(json.dumps(x,separators=(',',':')) for x in rows)+'\n'
   with tempfile.TemporaryDirectory() as t:
    p=Path(t)/'raw.stderr';p.write_text(raw);before=p.read_bytes()
    with self.assertRaises(ValueError):P.parse(p.read_text())
    self.assertEqual(p.read_bytes(),before)
 def test_json_and_lifecycle_failure(self):
  with self.assertRaises(ValueError):P.parse('{"type":"hc_observer_summary","valid":false,"valid":true}\n')
  rows=copy.deepcopy(self.rows);rows[0]['thread_changes']=1
  with self.assertRaises(ValueError):P.parse('\n'.join(json.dumps(x,separators=(',',':')) for x in rows))
 def test_prefix_minimality(self):
  def chunks(n):return [min(4096,n-1-i) for i in range(0,n-1,4096)]
  self.assertEqual(chunks(8192),[4096,4095]);self.assertEqual(chunks(12288),[4096,4096,4095]);self.assertFalse(any(chunks(n)==[4096,4096,4095] for n in range(1,12288)))
 def test_unknown_orphan_boolean_counter(self):
  bad=copy.deepcopy(self.rows);bad.append(dict(type='hc_observer_unknown',context=1,generation=1))
  orphan=copy.deepcopy(self.rows);extra=copy.deepcopy(next(x for x in orphan if x['type']=='hc_observer_weight'));extra['context']=8;orphan.append(extra)
  boolean=copy.deepcopy(self.rows);next(x for x in boolean if x['type']=='hc_observer_summary')['unmapped']=False
  for rows in (bad,orphan,boolean):
   with self.assertRaises(ValueError):P.parse('\n'.join(json.dumps(x,separators=(',',':')) for x in rows))
 def test_source_no_device_changes(self):
  proof=prepare.generate();self.assertEqual(proof['device_functions_unchanged'],9);self.assertTrue(proof['kernel_launch_lines_unchanged']);self.assertTrue(proof['device_copy_reset_sync_event_calls_unchanged'])
  header=(HERE/'hc_counts_observer.hpp').read_text();self.assertNotIn('cuda',header);self.assertNotIn('hip',header);self.assertNotIn('<<<',header);self.assertNotIn('%p',header)
  patch=(HERE/'observer.patch').read_text();self.assertNotIn('+    cuda',patch);self.assertIn('hc_observer::observe(hc_observation, guard)',patch)
if __name__=='__main__':unittest.main()
