#!/bin/sh
# Execute only by root inside the pinned ROCm container, /work writable, /qual read-only.
# No GPU device mount is needed. Never write /qual or rebuild its archive.
set -eu
cd /work
CLANG=/opt/rocm/lib/llvm/bin/clang++
AR=/opt/rocm/lib/llvm/bin/llvm-ar
BASE=10fd2dca11007b515da1fbb9192616cb63e67491a30bcb8e4754284628846a5b
CAND=21efb8501aa41ce938daa497c5b3196e275e39a4fadd9138da2cb4e8cf2aded1
HARNESS=0eac4ceb11f783e14977f35afdbe0bf6c39fbddaa0fe8c39675e4a0f346a667e
printf '%s  %s\n' "$BASE" /qual/src/kernels/cuda/qsa_select.cu | sha256sum -c -
printf '%s  %s\n' "$CAND" /work/qsa_select.fit17.cu | sha256sum -c -
printf '%s  %s\n' "$HARNESS" /work/qsa_topk_fixture_replay.cpp | sha256sum -c -
cp /qual/src/kernels/cuda/qsa_select.cu /work/qsa_select.base.cu
sha256sum /qual/build-906/libstrata_kernels.a > archive-before.sha256
C() {
    "$CLANG" -x hip -O3 -DNDEBUG -std=c++20 --offload-arch=gfx906 -Wall -Wextra \
      -DSTRATA_HIP_GFX906=1 -DUSE_PROF_API=1 -D__HIP_PLATFORM_AMD__=1 -D__HIP_ROCclr__=1 \
      -I/qual/include/strata/platform/hip_compat -I/qual/include "$@"
}
# Actual device-preprocessor output proves the chosen width32/wave64 ballot backend.
C -DSTRATA_GFX906_TOPK_FIT17_PROBE=1 --cuda-device-only -E -dD \
  qsa_select.fit17.cu -o qsa_select.fit17.device.ii
python3 - <<'PY'
import pathlib,re,json
p=pathlib.Path('qsa_select.fit17.device.ii');s=p.read_text()
assert '/qual/include/strata/platform/hip_compat/strata_hip.h' in s
assert '/strata/hip_compat/intrinsics.hpp' not in s
ballots=re.findall(r'^#define __ballot_sync[^\n]*',s,re.M)
assert ballots and 'strata_ballot32' in ballots[-1],ballots
assert re.search(r'b\s*>>\s*\(\s*__lane_id\s*\(\s*\)\s*&\s*32u',s)
shuffles=re.findall(r'^#define __shfl_sync[^\n]*',s,re.M)
assert shuffles and '__shfl(' in shuffles[-1],shuffles
pathlib.Path('preprocessor-proof.json').write_text(json.dumps({'platform_shim':True,'wrong_intrinsics_header_absent':True,'ballot_macro':ballots[-1],'shuffle_macro':shuffles[-1],'half_wave_shift_verified':True},indent=2)+'\n')
PY
# Sidecar baseline object is for actual resource/ISA comparison, not linked.
C -Rpass-analysis=kernel-resource-usage -save-temps=obj -c qsa_select.base.cu \
  -o qsa_select.baseline.o 2> baseline-resources.log
C -DSTRATA_GFX906_TOPK_FIT17_PROBE=1 -Rpass-analysis=kernel-resource-usage -save-temps=obj \
  -c qsa_select.fit17.cu -o qsa_select.fit17.o 2> fit17-resources.log
# Replace only the original qsa_select member in a COPY of the qualified archive.
cp /qual/build-906/libstrata_kernels.a /work/libstrata_kernels.fit17.a
"$AR" t libstrata_kernels.fit17.a > archive-members-before.txt
member=$(grep -E '(^|/)qsa_select\.(cu|hip|cpp)\.o$' archive-members-before.txt)
[ "$(printf '%s\n' "$member" | wc -l)" -eq 1 ] && [ -n "$member" ]
printf '%s\n' "$member" > removed-member.txt
"$AR" d libstrata_kernels.fit17.a "$member"
"$AR" rcs libstrata_kernels.fit17.a qsa_select.fit17.o
"$AR" t libstrata_kernels.fit17.a > archive-members-after.txt
[ "$(grep -Ec '(^|/)qsa_select\.fit17\.o$' archive-members-after.txt)" -eq 1 ]
if grep -Fqx "$member" archive-members-after.txt; then exit 1; fi
C /work/qsa_topk_fixture_replay.cpp -x none /work/libstrata_kernels.fit17.a \
  -L/opt/rocm/lib -Wl,-rpath,/opt/rocm/lib -lamdhip64 -o /work/qsa_topk_fit17_probe
if [ -f /work/qsa_reg17_transition.cpp ]; then
    C /work/qsa_reg17_transition.cpp -x none /work/libstrata_kernels.fit17.a \
      -L/opt/rocm/lib -Wl,-rpath,/opt/rocm/lib -lamdhip64 -o /work/qsa_reg17_transition
    sha256sum qsa_reg17_transition.cpp qsa_reg17_transition > transition-build-sha256.txt
fi
sha256sum /qual/build-906/libstrata_kernels.a > archive-after.sha256
cmp archive-before.sha256 archive-after.sha256
sha256sum qsa_select.base.cu qsa_select.fit17.cu qsa_select.baseline.o qsa_select.fit17.o \
  libstrata_kernels.fit17.a qsa_topk_fixture_replay.cpp qsa_topk_fit17_probe > build-sha256.txt
printf '%s\n' 'BUILD ONLY: inspect saved device ISA/resources before any GPU run.'
