#!/usr/bin/env bash
# Invoked only inside the pinned build container by compile-public-port.sh.
set -euo pipefail
exec > >(tee /work/build.stdout) 2> >(tee /work/build.stderr >&2)
set -x
BIN=/opt/rocm/lib/llvm/bin
CXX=$BIN/clang++
AR=$BIN/llvm-ar
NM=$BIN/llvm-nm
cd /work
sha256sum /archive/libstrata_kernels.a > archive-before.sha256
cp /archive/libstrata_kernels.a support.a
"$AR" t support.a > archive-members.txt
mapfile -t members < <(grep -E '(^|/)qsa_decode_attn\.cu\.(o|obj)$' archive-members.txt)
if (( ${#members[@]} != 1 )); then
  echo 'STOP: expected exactly one qsa_decode_attn archive member; inspect archive-members.txt.' >&2
  exit 3
fi
printf '%s\n' "${members[0]}" > removed-member.txt
"$AR" d support.a "${members[0]}"
"$AR" s support.a
"$NM" --defined-only --demangle support.a > support-defined.txt
if grep -E 'strata::kernels::qsa_decode_attn_(batch|step|scratch_floats)\(' support-defined.txt; then
  echo 'STOP: old QSA host definition remains in support archive.' >&2
  exit 3
fi
COMMON=(-O3 -DNDEBUG -std=c++20 --offload-arch=gfx906 -Wall -Wextra
 -DSTRATA_HIP_GFX906=1 -DUSE_PROF_API=1 -D__HIP_PLATFORM_AMD__=1 -D__HIP_ROCclr__=1
 -I/input/include/strata/platform/hip_compat -I/input/include)
"$CXX" --version > compiler.txt
"$CXX" -x hip "${COMMON[@]}" -Rpass-analysis=kernel-resource-usage -save-temps=obj \
 -c /input/src/kernels/cuda/qsa_decode_attn.cu -o public-qsa.o
"$CXX" -x hip "${COMMON[@]}" \
 -c /input/bench/gfx906_qsa_query_swizzle_probe.cpp -o published-probe.o
"$NM" --defined-only --demangle public-qsa.o > public-qsa-defined.txt
"$CXX" --hip-link --offload-arch=gfx906 -Wl,-Map=/work/public-probe.map \
 public-qsa.o published-probe.o support.a -o gfx906_qsa_query_swizzle_probe
"$NM" --defined-only --demangle gfx906_qsa_query_swizzle_probe > linked-defined.txt
for name in batch step scratch_floats; do
  test "$(grep -Ec " [TW] strata::kernels::qsa_decode_attn_${name}\\(" public-qsa-defined.txt)" -eq 1
  test "$(grep -Ec " [TW] strata::kernels::qsa_decode_attn_${name}\\(" linked-defined.txt)" -eq 1
done
grep -q 'public-qsa.o' public-probe.map
if grep -E 'support\.a\([^)]*qsa_decode_attn' public-probe.map; then
  echo 'STOP: link map unexpectedly references old QSA archive member.' >&2
  exit 3
fi
sha256sum public-qsa.o published-probe.o support.a gfx906_qsa_query_swizzle_probe > outputs.sha256
sha256sum /archive/libstrata_kernels.a > archive-after.sha256
cmp archive-before.sha256 archive-after.sha256
printf 'compile_link_symbol_checks_passed\n' > BUILD-PASSED
# No GPU device nodes are mounted. This script never invokes the probe.
