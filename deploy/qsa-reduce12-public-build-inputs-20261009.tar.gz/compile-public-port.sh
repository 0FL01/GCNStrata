#!/usr/bin/env bash
# Root-run preparation: compile exact public QSA source, do not run a GPU probe.
set -euo pipefail
INPUT=$(realpath "${1:?usage: compile-public-port.sh INPUT NEW_WORK [ARCHIVE]}")
WORK=${2:?NEW_WORK required}
ARCHIVE=$(realpath "${3:-/home/radneon/strata-rnd-hc-f16/build-906/libstrata_kernels.a}")
QUAL_QSA_HEADER=${QUAL_QSA_HEADER:-/home/radneon/strata-rnd-hc-f16/include/strata/kernels/qsa.hpp}
IMAGE=sha256:bccb7ee7e7a78274519db9a43ba63c34ddd2e74bb60f8764a8f50aaee1f2c646
(cd "$INPUT"; sha256sum --check public-build-inputs.sha256)
test "$(sha256sum "$INPUT/src/kernels/cuda/qsa_decode_attn.cu" | cut -d' ' -f1)" = ec0a11258848d6e2bf6ca0bbe463f06eada460a72be10ff5bb4dce065abe3ab0
# qsa_step_fill comes from the existing support archive; exact public header
# match is an ABI precaution. It does not establish the archive's provenance.
cmp "$INPUT/include/strata/kernels/qsa.hpp" "$QUAL_QSA_HEADER"
test -f "$ARCHIVE"
# Thin archives retain external object paths; require a self-contained archive.
test "$(head -c 7 "$ARCHIVE")" = "!<arch>"
mkdir "$WORK"  # Refuse to reuse a build/production directory.
WORK=$(realpath "$WORK")
sha256sum "$ARCHIVE" "$QUAL_QSA_HEADER" > "$WORK/support-inputs.sha256"
printf '%s\n' "$IMAGE" > "$WORK/container-image.txt"
cp "$INPUT/public-build-inputs.sha256" "$WORK/"
set +e
docker run --rm --network none \
 -v "$INPUT:/input:ro" -v "$ARCHIVE:/archive/libstrata_kernels.a:ro" \
 -v "$WORK:/work" -w /work --entrypoint /bin/bash "$IMAGE" \
 /input/compile-public-port-inner.sh
status=$?
set -e
printf '%s\n' "$status" > "$WORK/build.exit_code"
sha256sum --check "$WORK/support-inputs.sha256"
exit "$status"
