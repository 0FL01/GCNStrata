# gfx906: add opt-in QSA reduce12 score reduction

## Summary

Depends on [#1661](https://github.com/Niko1221/Strata/pull/1661), currently at `1f555de86254cc01ec06882c70f9584c1f09ec39`. This follow-on changes the score reduction in its INT8 query-swizzled batched QSA path: twelve warp sums become one reduce-scatter with the same butterfly pairings, reducing score shuffles from 60 to 16. Softmax, value accumulation, merge, and the published pre75/DPP implementation are unchanged.

Default-off. Set `STRATA_GFX906_ATTN_QUERY_SWIZZLE=1` and `STRATA_GFX906_ATTN_REDUCE12=1`, with lane-cell scoring disabled. The new flag requires exactly `1`. Dispatch retains #1661's current-device gfx906/wave64 guard and INT8 restriction. `STRATA_GFX906_ATTN_REDUCE12_TRACE=1` reports actual selection once per host thread. The setting is cached, so compare flag states in separate processes.

## Measurements

- Full QSA chunk + merge microbenchmark, `n_q=32`, context 65,536, A/B/B/A: latency 1.0351595 → 0.7583600 ms on GPU 0 and 1.0319200 → 0.7576400 ms on GPU 1, reductions of 26.739792% and 26.579580%. These are component latency reductions.
- All 16 micro runs passed, including `n_q=1/context=4` and masked-page `n_q=33/context=4096`. Full attention outputs and raw scores matched byte-for-byte by SHA-256. Full-kernel ISA: score shuffles/adds 60 → 16; dot FMACs 84 → 84; VGPR 42 → 48; occupancy four waves/SIMD; LDS 15,872 bytes; no scratch or spills.
- Whole-model 65,536-token prompt / 1,024-output A/B/B/A: PP 625.033728 → 646.536120 tok/s (+3.440197%); TG 52.280242 → 53.106939 tok/s (+1.581280%). Individual pairs: PP +3.43809% / +3.44230%, TG +1.61839% / +1.54418%. All 1,024 output IDs match in each pair.

The model comparison toggles only reduce12 on the frozen qualified8900 experimental stack: base `f152172332693c933b8a3104ce193d8a4315c2b4` plus HC, J32/grouped-MMQ, dequantization, query swizzle, empty-PCIe and primary-commit changes. Both arms retain `STRATA_PRIMARY_COMMIT_OVERLAP=1`; trace is off in timing arms. Those host optimizations are measurement context and are excluded from this patch. The micro and model measurements use the existing qualified gfx906 stack, rather than a fresh build of this rebased source.

The same frozen reduce12 candidate also passed a 4,096-token / 1,024-output matched pair (+3.070518% PP, +1.328129% TG, all IDs exact), a 200,000-token / 256-output capacity/parity run (616.858242 PP, 45.537017 TG, all IDs exact against the archived reference), and targeted API tools, two vision trials, cache restoration, auth/UI and disconnect/cancel checks. The 200K run has no fresh performance control. Configuration and Compose were restored byte-for-byte; the release has not been promoted.

[Archived report and receipts](https://github.com/0FL01/Strata/blob/44a92d54e192ca8554c534fc2f2673e8b2a904b5/bench/results/2026-10-09-gfx906-qsa-reduce12/qsa-reduce12-report.md) document that frozen-stack qualification. This local public-source rebase currently has source checks only. A separate public-source compile/component check is prepared but has not been run; no upstream CI pass or merge-readiness claim is made.

## Integration

Only `src/kernels/cuda/qsa_decode_attn.cu` changes. The implementation is scoped to the current fixed `G=12`. Unmerged [#1402](https://github.com/Niko1221/Strata/pull/1402) uses the third kernel template argument for `G`, while #1661 uses it for `QUERY_SWIZZLE` and this follow-on adds `REDUCE12` fourth. Integration needs an explicit template/dispatch reconciliation and must keep reduce12 gated to `G=12` until other geometries are separately qualified.
