# Isolated public-port compile and component qualification

## Current state

The frozen candidate has passed 64K ABBA, 4K parity/performance pair, 200K archived-reference parity/capacity and targeted API qualification. Published evidence: https://github.com/0FL01/Strata/blob/44a92d54e192ca8554c534fc2f2673e8b2a904b5/bench/results/2026-10-09-gfx906-qsa-reduce12/qsa-reduce12-report.md

The public port is still source-reviewed only. This packet prepares an actual compilation of its exact source and a production-path component test; it does not claim that either has run. PR-DRAFT.md now reflects completed frozen qualification and retains the separate public-build limitation. PR #1661's body remains untouched.

## Inputs and isolation

Stage this packet to a NEW directory, for example `/home/radneon/strata/logs/perf-campaign-20261009/qsa-reduce12-public-input`. It is a file bundle, not a modification of any checkout. The build output must be another NEW directory, for example `/home/radneon/strata/logs/perf-campaign-20261009/qsa-reduce12-public-build`.

`public-build-inputs.sha256` pins the compiled source, probe, public headers, compatibility headers, and run/build scripts. Ten unchanged probe/header files were fetched from exact public commit `1f555de86254cc01ec06882c70f9584c1f09ec39` and checked against their Git blob SHA. Their URLs and hashes are in `public-input-provenance.json`. The production QSA source has the expected `ec0a11258848d6e2bf6ca0bbe463f06eada460a72be10ff5bb4dce065abe3ab0` SHA-256.

The recipe reuses only the qualified static archive at `/home/radneon/strata-rnd-hc-f16/build-906/libstrata_kernels.a`. Its path and pinned compiler image are confirmed by the prior successful micro build receipt; its current bytes/existence must still be checked by root. Its original source tree is not built or edited. The archive is mounted read-only, copied into the new build directory and its old `qsa_decode_attn.cu.o` member is removed from that COPY. This makes linking an older QSA implementation impossible without a failed symbol check. Stop if the archive member naming differs; inspect, do not guess or fall back silently.

The unchanged public probe calls `qsa_step_fill` from the support archive. The wrapper requires an exact match of public `qsa.hpp` with the qualified header as an ABI precaution, and records the archive hash before/after. A header match is not proof of the archive's build provenance; retain its existing qualification/build receipt. If that comparison fails, stop and inspect the ABI difference or build the required public support TU in isolation. Do not drop the check blindly.

## Compile, root-run only

```bash
INPUT=/home/radneon/strata/logs/perf-campaign-20261009/qsa-reduce12-public-input
WORK=/home/radneon/strata/logs/perf-campaign-20261009/qsa-reduce12-public-build
bash "$INPUT/compile-public-port.sh" "$INPUT" "$WORK"
```

The script invokes pinned image `sha256:bccb7ee7e7a78274519db9a43ba63c34ddd2e74bb60f8764a8f50aaee1f2c646`, no network and no GPU devices. Exact public QSA and published probe are compiled into separate objects with `clang++ -x hip -O3 -DNDEBUG -std=c++20 --offload-arch=gfx906`, public include/compat paths, and the established gfx906/HIP definitions. No reduce12 test macro or score-only source is used. A separate HIP link combines those objects with the filtered support archive.

Required receipts:

- `build.exit_code=0` and `BUILD-PASSED`
- `build.stdout`, `build.stderr` (compiler resource report and xtraced exact commands), compiler version, container image
- Inputs and output SHA-256, unchanged support archive hash
- Removed archive member name, `support-defined.txt`, `public-qsa-defined.txt`, `linked-defined.txt`, and link map
- Exactly one definition of each `qsa_decode_attn_batch`, `qsa_decode_attn_step`, `qsa_decode_attn_scratch_floats` in the new object and final binary, with none in the filtered archive

This is a real public-source QSA compile and linked-component check, not a complete fresh upstream build or CI pass. Other archive members remain from the frozen support build and must be named in the eventual public validation scope.

## ISA gate before timing

The QSA compile uses `-save-temps=obj` and `-Rpass-analysis=kernel-resource-usage`. Preserve its gfx906 device assembly/intermediates. Review the full public-source A `<1,false,true,false>` and B `<1,false,true,true>` specializations before runtime:

- Expected full-kernel `ds_bpermute_b32`: 70 → 26; score region 60 → 16.
- Expected full-kernel `v_fmac_f32`: 87 → 87; score dot region 84 → 84.
- Prior resources: VGPR 42 → 48, SGPR 42 → 43, LDS 15,872 bytes, private segment 0, four waves/SIMD, zero spills.
- Verify the existing dot-product expression/order and reduction pairings. Any changed counts/resources require review, not an automatic assertion of equivalence.

The older `check-qsa-reduce12-isa-review.py` uses hard-coded addresses/registers from a prior binary. Do not run it against this new assembly and present its result as verification without adapting it to the new exact code. Retain new full-kernel disassembly and metadata or compiler assembly/resource receipts. Source equality alone is no substitute for this compiled check.

## Component tests, root-run only, exclusive GPU window

Reuse `run-existing-probe.sh` from this packet, already documented in `PROBE-REUSE.md`. Run the NEW `$WORK/gfx906_qsa_query_swizzle_probe` with the compatible qualified ROCm runtime; do not accidentally use the old diagnostic or old build binary. Record its exact SHA at execution. The runtime environment must not set a different visible device mask than the selected ordinal; respect the scheduler's isolation.

```bash
bash "$INPUT/run-existing-probe.sh" "$WORK/gfx906_qsa_query_swizzle_probe" "$WORK/gpu0" 0
bash "$INPUT/run-existing-probe.sh" "$WORK/gfx906_qsa_query_swizzle_probe" "$WORK/gpu1" 1
for tag in A1 B1 B2 A2 edge1-A edge1-B edge33-A edge33-B; do
  cmp "$WORK/gpu0/$tag.bin" "$WORK/gpu1/$tag.bin"
done
```

If the host lacks the required ROCm runtime, run that same wrapper in the established qualified runtime container with the new binary/input directories mounted; the compile-only container intentionally has no GPU device access. Do not infer a runtime failure from a missing host library or switch binaries silently.

Wrapper coverage: selected=1 trace smoke outside timing, four distinct A/B/B/A processes at 32 queries/context65536/reps50, all complete outputs compared byte-for-byte, edge1/context4 and edge33/context4096 masked-page parity, finite/written/guard/repeat checks and arithmetic of process medians. Query swizzle remains on, lane-cell off, only reduce12 switches; timing trace off. Each nq32 output is 786,432 bytes. Prior expected full-output SHA: `a00011ca8b03549db7aeaea38307583373bfdfebfa31e34207763903af9879a2`; edge1 `02664df8e50693193060413c9f8eaf55131eaf456b74245e8347b24e824c7c6f`; edge33 `24122feb972bfa4d0c33cacf0133b831b697a9e87af7085900d2a0447d73d4c8`. Compare these only after confirming input hashes match the frozen probe's deterministic input receipts.

Stop for build/link/source hash mismatch, actual-route failure, output mismatch, unexpected device, resource regression or failed existing component gate (at least 12% full chunk+merge latency reduction). Do not retune or alter public source to conceal a failure. Report the exact blocker and preserve logs. No production promotion, live source change, PR body edit or publication is part of this plan.
