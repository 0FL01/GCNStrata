#!/usr/bin/env python3
"""Exhaustive scalar/CPU proof of device partition; no GPU or compilation."""
from pathlib import Path
import itertools,json,random
SHORT=24576;FIT33=1024*33;FIT66=1024*66
def arms(nkvs):
 last=nkvs[-1];fits=max(n//4+1 for n in nkvs)<=FIT33
 return (last<=SHORT,last>SHORT and fits,last>SHORT and not fits)
def prove(rows):
 flags=arms(rows);assert sum(flags)==1
 if flags[1]:assert all(((n//4+1)+1023)//1024<=33 for n in rows)
 if flags[2]:assert all(((n//4+1)+1023)//1024<=66 for n in rows)
 return ('ref','mid33','wide66')[flags.index(True)]
for n in range(1,4*FIT66):
 route=prove([n])
 assert route==('ref' if n<=SHORT else 'mid33' if n<=135167 else 'wide66')
assert ((135167//4+1)+1023)//1024==33
assert ((135168//4+1)+1023)//1024==34
cases=[]
for T in [1,4,6,8]:
 for n in [24576,24577,135167,135168,200000,204800,270331]:
  rows=list(range(n-T+1,n+1));cases.append({'rows':rows,'arm':prove(rows)})
for rows in [[200000,65537],[200000,24576],[135168,135167],[270331,65537],[24577,24576]]:
 cases.append({'rows':rows,'arm':prove(rows)})
r=random.Random(331)
for _ in range(10000):
 rows=[r.randint(1,270331) for _ in range(r.randint(1,8))];prove(rows)
# Original host guards remain exact source text; simulate their scope only.
def host(nq,capacity,active,flag,old=False):
 if nq<=0:return 'none'
 counted=active>0;reach=active if counted and active<capacity else capacity
 extended=flag in [1,2] and not counted and nq<=8
 fit=FIT66 if counted or extended else FIT33
 if old or (counted and reach<7168) or reach>fit:return 'reference'
 if flag==2 and extended and reach>FIT33:return 'guarded'
 return 'reg33' if reach<=FIT33 else 'reg66'
host_cases=[]
for nq,cap,active,flag,old in itertools.product([0,1,4,6,8,9],[33792,33793,51202,67584,67585],[-1,6000,16386],[0,1,2,3],[False,True]):
 route=host(nq,cap,active,flag,old)
 if route=='guarded':assert 1<=nq<=8 and FIT33<cap<=FIT66 and active<=0 and flag==2 and not old
 host_cases.append(route)
out={'chronological_nkv_cases':4*FIT66-1,'random_unsorted_windows':10000,'host_scope_cases':len(host_cases),'all_exclusive_exhaustive':True,'middle_per_max':33,'wide_per_max':66,'exact_middle_nkv_limit':135167,'empty_tail_at_135168_requires_per':34,'boundary_and_nonmonotonic':cases,'GPU_or_build_run':False}
Path(__file__).with_name('guard-cpu-proof.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='boundary_and_nonmonotonic'},indent=2))
