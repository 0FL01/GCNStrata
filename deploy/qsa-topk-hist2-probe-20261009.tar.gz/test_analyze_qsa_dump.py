#!/usr/bin/env python3
import importlib.util, pathlib, struct, tempfile, random, json
p=pathlib.Path(__file__).with_name('analyze_qsa_dump.py')
spec=importlib.util.spec_from_file_location('a',p); a=importlib.util.module_from_spec(spec); spec.loader.exec_module(a)

def fixture(mode):
    T=4; pos0=65536; cap=2051; stride=51202
    h=[1,0x01020304,0,0,27,23,pos0,T,6,stride,cap,4,4,2048,128,4,stride*4,cap*4,16]
    steps=[(pos0+t,pos0+t+1,(pos0+t+1)//4,cap) for t in range(T)]
    out=bytearray(b'QSDUMP01'+struct.pack('<19q',*h))
    out+=b''.join(struct.pack('<4i',*s) for s in steps)
    rng=random.Random(70401)
    for pos,n,nb,w in steps:
        if mode=='equal': bits=[0x3e800000]*(nb+1)
        elif mode=='tied': bits=[struct.unpack('<I',struct.pack('<f',float(i%7)))[0] for i in range(nb+1)]
        else:
            bits=[struct.unpack('<I',struct.pack('<f',rng.gauss(0,1)))[0] for i in range(nb+1)]
            bits[0:6]=[0x7fc00001,0xffc00002,0x80000000,0,0x7f800000,0xff800000]
        if n%4: bits[nb]=0x4e6e6b28  # far-above finite tail
        keys=list(map(a.order_key,bits)); weights=[4]*nb+[n%4]
        # Independent cell-level order oracle, not the parser's blockwise select.
        cells=[(keys[b],4*b+c) for b in range(nb+1) for c in range(weights[b])]
        ids=sorted(c for _,c in sorted(cells,key=lambda x:(-x[0],x[1]))[:w])
        out+=struct.pack('<2q',nb+1,w)+struct.pack('<'+str(nb+1)+'I',*bits)+struct.pack('<'+str(w)+'i',*ids)
    return bytes(out)

with tempfile.TemporaryDirectory() as d:
    report=[]
    for mode in ['equal','tied','special_continuous']:
        p=pathlib.Path(d)/(mode+'.bin'); p.write_bytes(fixture(mode))
        r=a.analyze_file(p); assert r['all_ids_match']
        if mode=='equal': assert all(x['first_singleton_pass'] is None for x in r['rows'])
        report.append({'fixture':mode,'rows':len(r['rows']),'pass_counts':r['first_singleton_pass_counts']})
    source=fixture('equal'); rejected=0
    for bad in [source[:-1],source+b'x',b'BADDUMP!'+source[8:],source[:8]+struct.pack('<q',2)+source[16:]]:
        p=pathlib.Path(d)/'bad.bin';p.write_bytes(bad)
        try:a.read_dump(p)
        except ValueError:rejected+=1
        else:raise AssertionError('malformed fixture accepted')
    print(json.dumps({'synthetic_only':True,'gpu_run':False,'fixtures':report,'malformed_rejected':rejected},indent=2))
