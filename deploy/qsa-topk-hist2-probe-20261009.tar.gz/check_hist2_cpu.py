#!/usr/bin/env python3
"""Logical32-on-wave64 simulation of the bounded first-pass histogram; no GPU."""
import pathlib,sys,collections,json,random,hashlib,importlib.util
HERE=pathlib.Path(__file__).parent
sys.path.insert(0,str(HERE));import analyze_qsa_dump as a

def wave(digits,full,tail_weights):
    # Explicit physical64 ballot then low/high32 extraction, matching qualified HIP shim.
    assert len(digits)==len(full)==len(tail_weights)==64
    ballot=lambda pred:sum(int(v)<<i for i,v in enumerate(pred))
    base=[[0]*256 for _ in range(2)]; got=[[0]*256 for _ in range(2)]
    for lane,(digit,isfull,tail) in enumerate(zip(digits,full,tail_weights)):
        if isfull:base[lane//32][digit]+=4
        if tail:base[lane//32][digit]+=tail
    active=ballot(full);pending=[active&0xffffffff,(active>>32)&0xffffffff]
    atoms=0
    for _ in range(2):
        leaders=[(p & -p).bit_length()-1 if p else 0 for p in pending]
        bins=[digits[32*h+leaders[h]] for h in range(2)]
        same64=ballot([full[l] and digits[l]==bins[l//32] for l in range(64)])
        same=[(same64>>(32*h))&0xffffffff&pending[h] for h in range(2)]
        for h in range(2):
            if same[h]:got[h][bins[h]]+=4*same[h].bit_count();atoms+=1
            pending[h]&=~same[h]
    for l in range(64):
        if pending[l//32] & (1<<(l%32)):got[l//32][digits[l]]+=4;atoms+=1
        if tail_weights[l]:got[l//32][digits[l]]+=tail_weights[l];atoms+=1
    assert base==got,'physical64 / logical32 histogram mismatch'
    return got,atoms

def row(keys,nkv):
    nbid=nkv//4;nb=nbid+1;per=(nb+1023)//1024
    assert len(keys)==nb and per<=66
    base=[[0]*256 for _ in range(32)]; got=[[0]*256 for _ in range(32)];atoms=0
    for physical in range(16):
        for j in range(per):
            digits=[];full=[];tail=[]
            for l in range(64):
                b=(physical*64+l)*per+j
                digit=keys[b]>>24 if b<nb else 0
                f=b<nbid;w=nkv%4 if b==nbid else 0
                digits.append(digit);full.append(f);tail.append(w)
                if f:base[physical*2+l//32][digit]+=4
                if w:base[physical*2+l//32][digit]+=w
            hist,count=wave(digits,full,tail);atoms+=count
            for h in range(2):
                for d in range(256):got[physical*2+h][d]+=hist[h][d]
    assert base==got and sum(map(sum,got))==nkv
    return atoms

def main():
    out=pathlib.Path(sys.argv[1]) if len(sys.argv)>1 else HERE
    out.mkdir(parents=True,exist_ok=True)
    randomgen=random.Random(506122)
    # Empty halves; distinct leaders; different round2 participation in the two halves.
    wave_cases=0
    for full in [[False]*64,[True]*32+[False]*32,[False]*32+[True]*32,[True]*64]:
        for digits in [[193]*64,list(range(64)),[193]*32+list(range(32))]:
            wave(digits,full,[0]*64);wave_cases+=1
    for tail in [1,2,3]:
        for lane in [0,31,32,63]:
            full=[True]*64;full[lane]=False;weights=[0]*64;weights[lane]=tail
            wave([193 if i<32 else 194 for i in range(64)],full,weights);wave_cases+=1
    real=[]
    root=pathlib.Path('/home/opencode/ai/qsa-selection-capture-20261009')
    if root.exists():
        for device,stage in [(0,'0-27'),(1,'27-48')]:
            h,rows,sha,_=a.read_dump(root/f'window.dev{device}.layers{stage}.bin')
            for r in rows:
                keys=list(map(a.order_key,r['bits']));atoms=row(keys,r['step'][1])
                real.append({'device':device,'pos':r['step'][0],'baseline_atomics':r['step'][2]+int(r['step'][1]%4!=0),'hist2_atomics':atoms,'histogram_exact':True})
    synthetic=[]
    for nkv in [24577,65537,65538,65539,65540,204800,270332]:
        nb=nkv//4+1;per=(nb+1023)//1024
        for mode in ['equal','distinct_digits','random_bits']:
            if mode=='equal': keys=[0x80000000]*nb
            elif mode=='distinct_digits': keys=[((b//per)%32)<<24 for b in range(nb)]
            else:keys=[a.order_key(randomgen.getrandbits(32)) for _ in range(nb)]
            atoms=row(keys,nkv);synthetic.append({'nkv':nkv,'per':per,'mode':mode,'hist2_atomics':atoms,'histogram_exact':True})
    result={'physical_wave_cases':wave_cases,'real_rows':real,'synthetic_rows':synthetic,'all_histograms_exact':True,'GPU_run':False}
    (out/'hist2-cpu-check.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'all_histograms_exact':True,'physical_wave_cases':wave_cases,'real_rows':len(real),'synthetic_rows':len(synthetic),'GPU_run':False},indent=2))
if __name__=='__main__':main()
