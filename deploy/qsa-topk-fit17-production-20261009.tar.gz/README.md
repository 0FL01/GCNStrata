# Conditional clean scalar17 production patch

Prepared for a bounded native model test only if root's separate GPU1 scalar budget check justifies it. This preparation does not override either recorded30% component-screen failure and is not approval to promote the feature. No worker build, GPU execution, MI50 source write, or public PR change occurred.

Files:
- qsa_select.fit17.production.cu
- qsa-topk-fit17-production.patch
- source-proof.json
- prepare_production.py

Base source SHA:10fd2dca11007b515da1fbb9192616cb63e67491a30bcb8e4754284628846a5b.
Tested diagnostic source SHA:21efb8501aa41ce938daa497c5b3196e275e39a4fadd9138da2cb4e8cf2aded1.
Production source SHA:8d836acd211b7e493cd50bd680d128489f3f25f94ea26725afbab2402ef899bc.
Patch SHA:a00f7dbc888d77d32fba5b03d14a76915961016296f591b13815448d8fc2c20c.

## Behavior

STRATA_GFX906_TOPK_FIT17 enables only for the exact string1. Unset, empty,0,2,01,1junk,true or whitespace variants retain the old route. No diagnostic macro or mode2 remains. No hist2 code remains.

This opt-in still requires the original guarded gfx906 decode branch: TOPK_REG=2, uncounted calls,nq<=8, capacity exceeding33792 but fitting67584, and no OLD override. Counted prefill, other flags, smaller capacities and nq/capacity fallbacks remain unchanged.

When enabled, the reference guard is unchanged (last row n_kv<=24576). Otherwise the device maximum n_bid+1 over all<=8 rows chooses17 through17408blocks, or66 above it. Thus chronological n_kv69631 fits17 and69632 does not, including its empty tail. Arbitrary valid row ordering remains safe.

STRATA_GFX906_TOPK_FIT17_TRACE also requires exact string1. A thread-local once flag prints only when the opt-in three-arm branch is enabled. The line describes the enabled captured topology and explicitly says current device steps choose each window's arm; it does not pretend to observe a GPU per-window choice. No CUDA API query or synchronization was added for tracing. Existing legacy TOPK_TRACE behavior is untouched.

## Source proof

The complete original selection body from the output pointer through key loading, four radix passes, scans and ascending tie-stable emission is byte-identical to the baseline. Body SHA:f08194ed66d9915cb1d9711ae9215f7b150b3f83c0e8a6a2ed8899f9154c061d. The new device guards are byte-identical to the tested diagnostic guards. Scan and histogram geometry remain1024 threads,32 logical warps and32x256 histogram entries.

Controller git apply --check passes against the exact base. The source proof is not an emitted-ISA proof.

## Required diagnostic-to-production compile gate

Root must compare corresponding device functions after compilation:
- diagnostic <17,true,1,false> -> production <17,true,1>
- diagnostic <66,true,2,false> -> production <66,true,2>
- diagnostic <66,true,0,false> -> production <66,true,0>
- counted/default reg33 and reg66 instantiations, plus unchanged reference kernels

Compare normalized instruction bodies, kernel-argument layout and resource metadata; only template symbol names and placement may differ. Require the scalar17 and wide device programs to match the tested variant before relying on its parity or component receipts. Preserve the exact compiler command and original/production object hashes. A changed device body needs review rather than being called equivalent from source alone.

The host flag and trace behavior changed deliberately: diagnostic0/1/2 becomes exact1-only. Tests and source inspection must explicitly check that2 now selects baseline, and trace2 is silent. Per-thread once tracing must not be confused with per-device or per-window reporting.

Only root decides whether to build or run a native model ABBA after the second-device budget evidence. Keep the qualified source stack and all unrelated settings fixed.
